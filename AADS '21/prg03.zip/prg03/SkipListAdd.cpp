// ***** SkipListAdd.cpp *****

#include "master.h"

// add node to the list with info in ascending order  
bool SkipList::add(Node* newNode)
{
   // If there is no new node
   if (newNode == nullptr)
      // Return that the function did not add
      return false;  
    
   // If there is no head
   if (head[0] == nullptr){
      // Set the head to the new node
      head[0] = newNode;
      // Set the number of levels used to 1
      nLevelsUsed = 1;
   } else {
      // Create a current pointer to iterate through the skiplist
      Node* current = head[0];
      // Create a previous pointer for placement of new node
      Node* previous = head[0];
      // Create a flag for stopping the loop
      bool sorted = false;

      while (sorted == false){
         // If the head is greater than the new node
         if (head[0]->info > newNode->info){
            // Set the new node's next to what the first head pointer
            // is pointing at
            newNode->next[0] = head[0];
            // Set the first head pointer to point to the new node
            head[0] = newNode;
            // Set the result to sorted
            sorted = true;
         }
         // If current's info is greater than the new node's info
         else if (current->info > newNode->info){
            // Set the previous node's next to the new node
            previous->next[0] = newNode;
            // Set the new node's next to the current node
            newNode->next[0] = current;
            // Set the flag to ordered
            sorted = true;
         } else {
            // Set the previous pointer to point to current
            previous = current;
            // Set the current pointer to be current's next
            current = current->next[0];
            }
         }
      }
      
   return true;
}
/*
// a helper function to add to a particular level, currLevel.
// not required
Node* SkipList::addNext(Node* newNode, Node* prev, int currLevel)  
{
 
}*/

bool SkipList::find(int el) const {
   // Initialize found for flag
   bool found = false;
   // Initialize n for keeping track of head marker
   int n = nLevelsUsed - 1;
   // Initialize current pointer
   Node* current = nullptr;
   // Initialize num for holding number of nexts
   int num;

   // While n has not been fully checked and current has no been set
   while (n >= 0 && current == nullptr){
      // If the head's pointer at n is less than el, move to it
      if (head[n]->info <= el){
         // Set current at that head
         current = head[n];
         // Set the number of next pointers
         num = current->numOfNextPtrs;
      } else
         // Decrement down a head pointer
         n--;
   }
   
   // While the result has not be found and there is still a list to check
   while (found == false && current->next[0] != nullptr)
      // If the current info is the searched value
      if (current->info == el){
         // Searched value has been found
         found = true;
      }
      else {
         // If the current's highest next pointer is less than or is el
         if (current->next[num]->info <= el){
            // Move the current to that
            current = current->next[num];
            // Reset the num
            num = current->numOfNextPtrs;
         } else
            // Decrement the number
            num--;
   }

   return found;
}    