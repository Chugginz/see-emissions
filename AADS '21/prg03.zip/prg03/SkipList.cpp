// ***** SkipList.cpp *****

#include "master.h"

SkipList::SkipList (void)
{

   for (int i=0; i< MaxNumberOfLists; i++) {
      head[i] = nullptr;
   }
   nLevelsUsed = 0; 

}

SkipList::~SkipList (void)
{
   erase ();

   return;
}

void SkipList::erase (void)
{
   cout << "SkipList::erase\n";

   Node* tmp = head[0];  //use the layer-0 to remove nodes
   while (tmp)
   {
      Node* nextHead = tmp->next[0];
      delete tmp;
      tmp = nextHead;
   }

   // reset
   // clear the head[] 
   for (int i=0; i< nLevelsUsed; i++) {  
      head[i] = nullptr;
   }

   nLevelsUsed=0;

   return;
}


// To remove the node with given value from the list
// input: int el 
// output: bool to indicate el deleted or not (not exist)
/*
bool LinkedList::erase (int el)
{


}
*/

void SkipList::write (ostream& outfile) const
{

   Node* current = head[0];
   outfile << "current # of levels is " << nLevelsUsed << endl;
   while (current != nullptr)
   {
      outfile << *current << endl;
      current = current->next[0];
   }

   return;
}   

ostream& operator << (ostream& outfile, const SkipList& list)
{
   list.write (outfile);

   return outfile;
}